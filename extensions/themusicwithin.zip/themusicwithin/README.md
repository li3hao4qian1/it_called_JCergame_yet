# JCerGame *澎湃声乐* 扩展包

### 适用于 0.0.8.4 版本 *图文声像更新 “声”部分* 及以上版本

增加了3首背景音乐：

- Batty McFaddin - Kevin MacLeod

- Doh De Oh - Kevin MacLeod

- Royal Banana - Kevin MacLeod

要使用此扩展，请按照以下步骤操作：

1. 下载相同版本的扩展包。

	- [来源1，指向GitHub](https://github.com/https://github.com/li3hao4qian1/it_called_JCergame_yet/extensions/themusicwithin.zip)

	- [来源2，链接至外网Code+](https://cooode.top/d/xd_1/file/727/themusicwithin.zip)

	- [来源3，指向作者博客](https://li3hao4qian1.github.io/complex/games/themusicwithin.zip)

	- 如果你没有使用最新版本的 JCerGame，请使用 *来源1* 并检出过去的版本。

2. 提取压缩包。

	- 如果结果文件夹的名称不为此，请将其重命名为 *themusicwithin*。

	- 将文件夹放在与JCerGame相同的文件夹中。

3. 使用该扩展包。

	- 打开 JCerGame，选择“设置”，然后查看“澎湃声乐”的状态。

	- 如果显示“未加载”或“不可用”，请重新执行步骤，或向作者寻求帮助。

	- 如果显示“就绪”或“基本就绪”，你现在就可以使用此扩展包了。恭喜！

***

# JCerGame *The Music Within* extension

### for version 0.0.8.4 *Multimedia Update Pt. Sounds* and above

which adds 3 background musics:

- Batty McFaddin - Kevin MacLeod

- Doh De Oh - Kevin MacLeod

- Royal Banana - Kevin MacLeod

To use this extension, please follow these simple steps:

1. Download the same version of JCerGame.

	- [Source 1, Leads to GitHub](https://github.com/https://github.com/li3hao4qian1/it_called_JCergame_yet/extensions/themusicwithin.zip)

	- [Source 2, Leads to external Code+](https://cooode.top/d/xd_1/file/727/themusicwithin.zip)

	- [Source 3, leads to author's blog](https://li3hao4qian1.github.io/complex/games/themusicwithin.zip)

	- If you're not using the latest version of JCerGame, use *Source 1* and checkout versions in the past.

2. Extract the extension.

	- Rename the result folder's name into *themusicwithin* if its name doesn't like it.

	- Put the folder as the same folder as JCerGame.

3. Using the extension.

	- Open JCerGame, choose *Settings*, then check the status of *The Music Within".

	- If it shows *Unloaded* or *Unavailable*, follow the steps again or ask author for help.

	- If it shows *Ready* or *Generally Ready*, you can use this extension now. Congrats!